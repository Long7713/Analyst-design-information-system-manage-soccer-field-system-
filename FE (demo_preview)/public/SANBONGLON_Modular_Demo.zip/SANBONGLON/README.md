# SANBONGLON — Hệ Thống Quản Lý & Điều Phối Sân Bóng (Refactored Modular Demo)

Dự án Front-End Demo hoàn chỉnh cho hệ thống quản lý và điều phối cụm 12 sân bóng **SANBONGLON**, được tái cấu trúc (refactor) từ bộ thiết kế Google Stitch sang kiến trúc **Modular Component** với hệ thống Design Token tập trung theo đúng ngôn ngữ **Warm Editorial Studio (`DESIGN.md`)**.

---

## 1. Cấu trúc thư mục dự án

```text
SANBONGLON/
├── index.html                      # Điểm vào chính của ứng dụng
├── components/
│   └── sidebar.html                # HTML fragment Sidebar dùng chung (Single Source of Truth)
├── css/
│   ├── variables.css               # Hệ thống Design Tokens (Màu sắc, Typography, Spacing, Glass, Z-index)
│   ├── global.css                  # Reset, quy tắc 2+1 Fonts (Newsreader, Manrope, Space Mono) & Fallbacks
│   ├── layout.css                  # Application Shell, Top Header 3-Zone & Grid vận hành
│   ├── sidebar.css                 # Styles cho Sidebar (Expanded 256px, Collapsed 72px + Tooltip, Mobile Drawer)
│   ├── components.css              # Chuẩn hóa Buttons, Status Indicators, Forms, Tables, Modals, Drawers, Toasts
│   ├── animations.css              # Micro-interactions mượt mà & hỗ trợ prefers-reduced-motion
│   ├── responsive.css              # Đa thiết bị (Desktop, Tablet, Mobile Off-Canvas Drawer)
│   └── pages.css                   # Timeline lịch 12 sân (07:00-24:00) & Giao diện POS tại quầy
├── js/
│   ├── sidebar-config.js           # Cấu hình tập trung cho Sidebar (Logo, Tên, Nhãn, Icon, URL, Nhóm menu)
│   ├── sidebar.js                  # Bộ nạp fetch('/components/sidebar.html'), thu gọn/mở rộng & Mobile Drawer
│   ├── navigation.js               # Quản lý trạng thái active và điều hướng giữa các trang
│   ├── demo-data.js                # Dữ liệu mẫu thực tế cho 12 sân bóng, POS, khách hàng, kho & tài chính
│   └── app.js                      # Logic tương tác cho các trang HTML độc lập
├── pages/
│   ├── dashboard.html              # Tổng quan vận hành cụm 12 sân
│   ├── schedule.html               # Trung tâm điều phối sân / Lịch đặt sân (07:00–24:00)
│   ├── bookings.html               # Quản lý phiếu đặt sân & nhận sân
│   ├── customers.html              # Quản lý khách hàng, đội bóng & cảnh báo Boom
│   ├── pos.html                    # Dịch vụ & POS bán hàng tại quầy
│   ├── equipment.html              # Quản lý thiết bị & báo cáo sự cố
│   ├── inventory.html              # Quản lý kho hàng, tồn kho & phiếu nhập kho
│   ├── staff.html                  # Quản lý nhân sự & phân ca trực
│   ├── revenue.html                # Báo cáo doanh thu & tài chính
│   ├── analytics.html              # Thống kê vận hành & 5 phân khu phân tích chuyên sâu
│   ├── audit-log.html              # Nhật ký hoạt động & vết kiểm toán
│   ├── account-settings.html       # Tài khoản, bảo mật & trình tùy biến Sidebar trực tiếp
│   └── login.html                  # Đăng nhập ca trực & quản trị (Standalone layout)
├── public/
│   └── index.html                  # Trang chủ / Lịch sân công khai & Bảng giá niêm yết (Không gắn Sidebar quản trị)
└── README.md
```

---

## 2. Hướng dẫn chạy dự án tại máy cục bộ (Local Execution)

Vì thành phần `components/sidebar.html` được nạp động qua `fetch()`, bạn nên khởi chạy thông qua một máy chủ HTTP cục bộ thay vì mở trực tiếp bằng giao thức `file://`:

### Cách 1: Chạy môi trường Vite Development Server (Khuyên dùng)
```bash
npm install
npm run dev
```
Sau đó mở trình duyệt tại địa chỉ: `http://localhost:3000`

### Cách 2: Chạy máy chủ HTTP tĩnh cho bộ HTML thuần
```bash
npx serve public -l 3000
# hoặc dùng Python:
python3 -m http.server 3000 --directory public
```

---

## 3. Hướng dẫn tùy biến Sidebar tại một nơi duy nhất

Toàn bộ cấu hình của Sidebar được đặt tại tệp **`js/sidebar-config.js`** (và đồng bộ tại **`src/config/sidebarConfig.ts`**). Bạn cũng có thể chỉnh sửa trực tiếp trên giao diện tại mục **Cài đặt hệ thống**.

Để đổi tên thương hiệu, độ rộng hoặc thêm/sửa mục menu, chỉ cần chỉnh sửa đối tượng `window.SANBONGLON_SIDEBAR_CONFIG`:

```javascript
window.SANBONGLON_SIDEBAR_CONFIG = {
  brand: {
    logoText: 'SB',                 // Ký hiệu hiển thị trên biểu tượng vuông màu xanh cốm
    name: 'SANBONGLON',             // Tên thương hiệu chính
    subtitle: 'CENTRAL PITCH OPS',  // Dòng mô tả kỹ thuật bên dưới
    homeUrl: '/pages/dashboard.html'
  },
  appearance: {
    expandedWidth: '256px',         // Độ rộng khi mở rộng
    collapsedWidth: '72px',         // Độ rộng khi thu gọn (chỉ hiện icon + tooltip)
    defaultCollapsedDesktop: false
  },
  groups: [
    {
      id: 'dieu-phoi',
      label: 'ĐIỀU PHỐI & LỊCH SÂN',
      items: [
        {
          id: 'tong-quan',
          label: 'Tổng quan',
          icon: 'LayoutDashboard',  // Tên chuẩn Lucide Icon
          url: '/pages/dashboard.html',
          badge: '12 sân'
        }
        // ...
      ]
    }
  ]
};
```

---

## 4. Tóm tắt các cải tiến UI/UX & Thiết kế (Warm Editorial Studio)

1. **Tái sử dụng Sidebar 100%**: Loại bỏ hoàn toàn việc lặp mã HTML của Sidebar trên từng trang. Hỗ trợ đóng/mở mượt mà (`Ctrl + B`), hiển thị tooltip khi thu gọn, tự động đóng ngăn kéo (off-canvas drawer) khi chọn mục trên thiết bị di động.
2. **Chuẩn hóa Hệ thống Biểu tượng (Lucide Icons)**: Đồng bộ độ dày nét vẽ (`stroke-width: 1.8`), kích thước (`16px` cho bảng, `18px` cho nút điều khiển, `20px` cho điều hướng chính). Loại bỏ hoàn toàn việc trộn lẫn emoji hoặc nhiều thư viện icon xung đột.
3. **Đồng nhất Token Warm Editorial Studio (`DESIGN.md`)**:
   - Nền kem ấm (`#F4F1EA`), bề mặt cát (`#EBE6DC`), chữ Espresso đậm (`#1C1A17`), điểm nhấn Xanh cốm (`#7AC238`) và Rêu (`#586955`).
   - Quy tắc 2+1 Font chữ: **Newsreader** cho tiêu đề biên tập, **Manrope** cho giao diện vận hành và bảng biểu, **Space Mono** (`tabular-nums`) cho khung giờ, mã phiếu, số tiền và nhật ký kiểm toán.
4. **Hiệu ứng Kính Mờ Tinh Tế (Subtle Glass-Feel)**: Áp dụng có chọn lọc trên Sidebar, Top Header, Dropdown thông báo, Ngăn kéo điều phối đặt sân (Booking Drawer) và Modal, đi kèm lớp nền đặc dự phòng (`@supports not (backdrop-filter)`), tuyệt đối không làm mờ bảng lịch sân hay dữ liệu tài chính.
5. **Tối ưu hóa Lịch 12 Sân (07:00 – 24:00)**: Cột tên sân cố định (`sticky`), phân biệt trạng thái bằng cả màu sắc ngữ nghĩa + biểu tượng + nhãn văn bản rõ ràng (`ĐÃ NHẬN`, `ĐÃ CỌC`, `CHỜ CỌC`, `BOOM`).

---

## 5. Danh sách tương tác đã bảo toàn & hoàn thiện

- **Điều phối & Lịch sân**: Lọc theo sân 5 người / 7 người, lọc theo trạng thái, tìm kiếm nhanh theo tên đội/SĐT/mã phiếu, nhấn vào khung giờ trống để mở form **Đặt sân mới** (có kiểm tra trùng lịch), nhấn vào khối đặt sân để mở ngăn kéo thực hiện: **Nhận sân**, **Thêm giờ (+30p)**, **Đổi giờ**, **Thêm món POS**, **Báo boom**, **Hủy sân**.
- **POS Bán hàng tại quầy**: Lọc danh mục, tìm kiếm sản phẩm, tăng/giảm số lượng trong giỏ, gắn hóa đơn nước vào sân đang đá hoặc thu tiền khách lẻ (`Chuyển khoản QR` / `Tiền mặt`), tự động trừ tồn kho và ghi nhận doanh thu.
- **Quản lý Khách hàng, Thiết bị & Kho hàng**: Thêm hồ sơ đội bóng mới, tự động phân loại rủi ro Boom sân, lập phiếu báo cáo sự cố kỹ thuật, nghiệm thu sự cố, tạo phiếu nhập kho hàng hóa và xem thẻ kho.
- **Thống kê 5 trụ cột & Kiểm toán**: Chuyển đổi tức thời giữa 5 phân khu phân tích chuyên sâu và xuất báo cáo CSV.
- **Trang công khai & Đăng nhập ca trực**: Tách biệt hoàn toàn khỏi khung quản trị nội bộ nhưng giữ trọn vẹn nhận diện thương hiệu SANBONGLON.

---

## 6. Giới hạn đã biết (Known Limitations)

- Đây là bản **Front-End Demo** phục vụ trải nghiệm giao diện, luồng điều phối và kiến trúc mã nguồn; mọi thao tác cập nhật dữ liệu (đặt sân, thanh toán POS, nhập kho, báo sự cố) được lưu trữ trong bộ nhớ phiên làm việc của trình duyệt và không kết nối tới cơ sở dữ liệu máy chủ thực.
