# SANBONGLON – Quản Lý & Điều Phối Sân Bóng (Refactored Modular Demo)

Phiên bản Front-End Demo hoàn chỉnh cho hệ thống quản lý điều phối cụm 12 sân bóng **SANBONGLON**, được cấu trúc theo kiến trúc **Modular Component** và hệ thống Design Token tập trung theo đúng ngôn ngữ thiết kế **Warm Editorial Studio (`DESIGN.md`)**.

## 1. Cấu trúc thư mục

```text
SANBONGLON/
├── index.html                      # Điểm vào chính của ứng dụng
├── components/
│   └── sidebar.html                # HTML fragment Sidebar dùng chung (Single Source of Truth)
├── css/
│   ├── variables.css               # Hệ thống Design Tokens (Màu sắc, Typography, Spacing, Glass, Z-index)
│   ├── global.css                  # Reset, quy tắc 2+1 Fonts (Newsreader, Manrope, Space Mono) & Fallbacks
│   ├── layout.css                  # Application Shell, Top Header 3-Zone & Grid vận hành
│   ├── sidebar.css                 # Styles cho Sidebar (Expanded 256px, Collapsed 72px + Tooltip, Mobile Drawer)
│   ├── components.css              # Chuẩn hóa Buttons, Status Indicators, Forms, Tables, Modals, Drawers, Toasts
│   ├── animations.css              # Micro-interactions mượt mà & hỗ trợ prefers-reduced-motion
│   ├── responsive.css              # Đa thiết bị (Desktop, Tablet, Mobile Off-Canvas Drawer)
│   └── pages.css                   # Timeline lịch 12 sân (07:00-24:00) & Giao diện POS tại quầy
├── js/
│   ├── sidebar-config.js           # Cấu hình tập trung cho Sidebar (Logo, Tên, Nhân sự, Icon, URL, Nhóm menu)
│   ├── sidebar.js                  # Bộ nạp fetch('/components/sidebar.html'), thu gọn/mở rộng & Mobile Drawer
│   ├── navigation.js               # Quản lý trạng thái active và đồng bộ các trang
│   ├── demo-data.js                # Dữ liệu thực tế cho 12 sân bóng, POS, khách hàng, kho & tài chính
│   ├── app.js                      # Logic tương tác và đồng hồ thời gian thực cho các trang HTML
│   ├── toast.js                    # Thông báo toast
│   └── modal.js                    # Quản lý modal và drawer
└── pages/
    ├── dashboard.html              # Tổng quan vận hành cụm 12 sân
    ├── schedule.html               # Trung tâm điều phối / Lịch sân (07:00 – 24:00)
    ├── bookings.html               # Quản lý phiên sân & nhận sân
    ├── customers.html              # Quản lý khách hàng, đội bóng & cảnh báo Boom
    ├── pos.html                    # Dịch vụ & POS bán hàng tại quầy
    ├── equipment.html              # Quản lý thiết bị & bảo trì
    ├── inventory.html              # Quản lý kho hàng, tồn kho & phiếu nhập kho
    ├── staff.html                  # Quản lý nhân sự & phân ca trực
    ├── revenue.html                # Báo cáo doanh thu & tài chính
    ├── analytics.html              # Thống kê vận hành & 5 phân khu phân tích chuyên sâu
    ├── audit-log.html              # Nhật ký & vết kiểm toán
    ├── account-settings.html       # Tài khoản, bảo mật ca trực
    └── login.html                  # Đăng nhập ca trực & quản trị (gọn nhẹ)
```

## 2. Thông tin nhân sự vận hành
- Tên nhân viên điều phối: **Trương Thịnh Phát** (Mã: `SBL-NV01`)
- Chức danh: **Điều phối viên trưởng cụm 12 sân**
- Ký hiệu avatar: **TTP**

## 3. Cải tiến giao diện & Tính năng theo yêu cầu
- **Đồng hồ thời gian thực ở Top Bar**: Hiển thị thứ, giờ, phút, giây định dạng `Thứ Giờ:phút:giây` (ví dụ: *Thứ Hai 16:05:22*).
- **Tinh gọn Top Bar**: Bỏ nút tiếp cận nhanh "Lịch 12 sân", "Quầy POS" và bỏ hiển thị mã ca làm việc để giao diện thông thoáng, tinh tế.
- **Tối giản Đăng nhập ca trực**: Xóa bỏ các trường "Tiền tồn quỹ đầu ca" và "Ca làm việc nhận bàn giao", chỉ cần nhập tài khoản và mật khẩu để vào ca trực.
- **Tối giản Cài đặt hệ thống**: Bỏ phần "Cấu hình Sidebar tập trung", tập trung vào bảo mật tài khoản và quản lý mật khẩu ca trực.
